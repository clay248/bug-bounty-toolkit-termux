#!/bin/bash

pkg update -y && pkg upgrade -y

pkg install git -y
pkg install golang -y
pkg install python -y
pkg install wget -y

go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
