# Bug Bounty Beginner Guide

## Recon Workflow

1. Subdomain enumeration
2. Live host discovery
3. Parameter discovery
4. Vulnerability scanning

## Tools Used

- subfinder
- amass
- httpx
- nuclei
- sqlmap
- ffuf
