# Bug Bounty Toolkit for Termux

This repository contains tools and setup scripts for bug bounty hunting using Termux.

## Tools included

- Subfinder
- Amass
- Httpx
- Nuclei
- SQLmap
- FFUF

## Purpose

Help beginner bug hunters set up a recon environment on Android using Termux.
